# KrampusUI
simple Ro-Exec/Krampus UI i made in an hour and a half
![image](https://github.com/LokoBurrito/KrampusUI/assets/81943357/7ffe841f-12e4-4de9-a747-e488b7a7e0e2)
This file does not contain the Krampus app, and this project doesn't allow you to get Krampus/Ro-Exec for free. You'll need the .exe file from the loader.live site to use the application.
